// d:\Users\HollowME\Desktop\StockMaster\email_server\server.js

// 1. Import necessary packages
import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';

// Import all route modules
import authRoutes from './authRoutes.js';
import productRoutes from './productRoutes.js';
import receiptRoutes from './receiptRoutes.js';
import deliveryRoutes from './deliveryRoutes.js';
import locationRoutes from './locationRoutes.js';
import vendorRoutes from './vendorRoutes.js';
import stockRoutes from './stockRoutes.js';
import transferRoutes from './transferRoutes.js';
import adjustmentRoutes from './adjustmentRoutes.js';
import dashboardRoutes from './dashboardRoutes.js';

// 2. Configure environment variables
dotenv.config();

// 3. Create the Express app
const app = express();
const PORT = process.env.PORT || 3000;

// 4. Add middleware
// Enable CORS for all origins
app.use(cors({
  origin: ['http://localhost:8080', 'http://localhost:5173', 'http://localhost:3000'],
  credentials: true
}));

// This allows your server to understand JSON request bodies
app.use(express.json());

// 5. Define routes
// Authentication routes
app.use('/api/auth', authRoutes);

// Products routes
app.use('/api/products', productRoutes);

// Receipts routes
app.use('/api/receipts', receiptRoutes);

// Deliveries routes
app.use('/api/deliveries', deliveryRoutes);

// Locations routes
app.use('/api/locations', locationRoutes);

// Vendors routes
app.use('/api/vendors', vendorRoutes);

// Stock routes
app.use('/api/stock', stockRoutes);

// Transfers routes
app.use('/api/transfers', transferRoutes);

// Adjustments routes
app.use('/api/adjustments', adjustmentRoutes);

// Dashboard routes
app.use('/api/dashboard', dashboardRoutes);

// A simple root route to check if the server is running
app.get('/', (req, res) => {
  res.send('StockMaster API is running!');
});

// 6. Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
  console.log(`CORS enabled for frontend on http://localhost:5173`);
  console.log(`Available API endpoints:`);
  console.log(`  POST /api/auth/login`);
  console.log(`  GET  /api/products`);
  console.log(`  GET  /api/receipts`);
  console.log(`  GET  /api/deliveries`);
  console.log(`  GET  /api/locations`);
  console.log(`  GET  /api/vendors`);
  console.log(`  GET  /api/stock`);
  console.log(`  GET  /api/transfers`);
  console.log(`  GET  /api/adjustments`);
  console.log(`  GET  /api/dashboard/stats`);
});
